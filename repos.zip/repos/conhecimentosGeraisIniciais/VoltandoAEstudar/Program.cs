﻿using System;
using VoltandoAEstudar;

namespace VoltandoAEstudar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //Triangulo x, y;
            // x = new Triangulo();
            // y = new Triangulo();

            //Console.WriteLine("Digite o valor de um dos lados do Triângulo X");
            //x.A = int.Parse(Console.ReadLine());
            //Console.WriteLine("Digite o valor de um dos lados do Triângulo X");
            //x.B = int.Parse(Console.ReadLine());
            //Console.WriteLine("Digite o valor de um dos lados do Triângulo X");
            //x.C = int.Parse(Console.ReadLine());

            //Console.WriteLine("Digite o valor de um dos lados do Triângulo Y");
            //y.A = int.Parse(Console.ReadLine());
            //Console.WriteLine("Digite o valor de um dos lados do Triângulo Y");
            //y.B = int.Parse(Console.ReadLine());
            //Console.WriteLine("Digite o valor de um dos lados do Triângulo Y");
            //y.C = int.Parse(Console.ReadLine());



            //Pessoa a, b;
            //a = new Pessoa();
            //b = new Pessoa();

            //Console.WriteLine("Digite o nome da primeira pessoa");
            //a.Nome = Console.ReadLine();

            //Console.WriteLine("Digite o nome da segunda pessoa");
            //b.Nome = Console.ReadLine();

            //Console.WriteLine("Digite a idade da primeira pessoa");
            //a.Idade = int.Parse(Console.ReadLine());

            //Console.WriteLine("Digite a idade da segunda pessoa");
            //b.Idade = int.Parse(Console.ReadLine());

            //if (b.Idade > a.Idade)
            //{
            //    Console.WriteLine("A pessoa mais velha é a " +  b.Nome);
            //} else
            //{
            //    Console.WriteLine("A pessoa mais velha é a " +  a.Nome);
            //}



            Produto p = new Produto();

            Console.WriteLine("Entre com os dados do produto ");
            Console.Write("Nome : ");
            p.Nome = Console.ReadLine();
            Console.Write("Preço : ");
            p.Preco = double.Parse(Console.ReadLine());
            Console.Write("Quantidade : ");
            p.Quantidade = double.Parse(Console.ReadLine());

            Console.WriteLine("Dados do produto : " + p);

        }
    }
}