﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoltandoAEstudar
{
    internal class Triangulo
    {
        public double A;
        public double B;
        public double C;
    }
}
