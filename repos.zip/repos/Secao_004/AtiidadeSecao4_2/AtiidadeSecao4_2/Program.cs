﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtiidadeSecao4_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Funcionario func;
            func = new Funcionario();

            double porcentagem;

            Console.WriteLine("Digite o nome do funcionário");
            func.Nome = Console.ReadLine();

            Console.WriteLine("Digite o valor do salário bruto do funcionário");
            func.SalarioBruto = Double.Parse(Console.ReadLine());

            Console.WriteLine("Funcionário: " +  func.Nome +", $" + func.SalarioLiquido());
            Console.Write("Digite a porcentagem para aumentar o salário do funcionário: ");

            porcentagem = double.Parse(Console.ReadLine());
            func.AumentarSalario(porcentagem);
            Console.WriteLine("Dados atualizados: " + func.Nome + ", $" + func.SalarioLiquido());
        }
    }
}
