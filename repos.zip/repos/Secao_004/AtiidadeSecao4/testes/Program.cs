﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string a, b, c;
            

            menu();
            Console.WriteLine("Digite o valor do primeiro lado");
            a = (Console.ReadLine());
            Console.WriteLine("Digite o valor do segundo lado");
            b = (Console.ReadLine());
            Console.WriteLine("Digite o valor do terceiro lado");
            c = (Console.ReadLine());

            Console.WriteLine(Calculo(a, b, c));


        }

        static void menu()
        {
            Console.WriteLine("==========================================================\nDigite 3 valores que serão alocas em lados de um triângulo\n==========================================================\n\n");
        }

        static string Calculo (string a, string b, string c) {

            string resul = "";

            if (a == b && b == c && a == c)
            {
                resul += "O triângulo é equilátero";
            }
            else if (a != b && b != c && a != c)
            {
                resul += "O triângulo é escaleno";
            }
            else
            {
                resul += "o triângulo é isóceles";
            }
         
            return resul;
        }


    }
}
